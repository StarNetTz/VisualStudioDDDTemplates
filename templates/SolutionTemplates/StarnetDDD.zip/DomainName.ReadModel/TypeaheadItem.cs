﻿namespace $safeprojectname$
{
    public class TypeaheadItem
    {
        public string Id { get; set; }
        public string Value { get; set; }
    }
}
