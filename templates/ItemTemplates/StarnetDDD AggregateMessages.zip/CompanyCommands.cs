﻿namespace $rootnamespace$.Commands
{
    public class Create$fileinputname$ : Command
    {
        public string Name { get; set; }
    }
}
