﻿namespace $rootnamespace$.Events
{
    public class $fileinputname$Created : Event
    {
        public string Name { get; set; }
    }
}
