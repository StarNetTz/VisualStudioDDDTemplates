﻿using _DOMAIN_.PL.Commands;
using _DOMAIN_.PL.Events;
using Starnet.Aggregates;

namespace $rootnamespace$.$fileinputname$
{
    public class $fileinputname$Aggregate : Aggregate
    {
        private $fileinputname$AggregateState State;

        public $fileinputname$Aggregate($fileinputname$AggregateState state) : base(state)
        {
            State = state;
        }

        internal void Create$fileinputname$(Create$fileinputname$ c)
        {
            var e = new $fileinputname$Created() 
			{ 
				Id = c.Id, 
				IssuedBy = c.IssuedBy, 
				TimeIssued = c.TimeIssued,
                Name = c.Name
            };
            Apply(e);
        }
    }
}
