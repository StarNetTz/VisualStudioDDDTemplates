﻿using _DOMAIN_.PL.Events;
using Starnet.Aggregates;

namespace $rootnamespace$.$fileinputname$
{
    public class $fileinputname$AggregateState : AggregateState
    {
        string Name { get; set; }

        protected override void DelegateWhenToConcreteClass(object ev)
        {
            When((dynamic)ev);
        }

        private void When($fileinputname$Created e)
        {
            Id = e.Id;
            Name = e.Name;
        }
    }
}